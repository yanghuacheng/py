def opens(obj,name,w="r"):
	fo = open(name, w).read()
	return fo
	