
from package import opens
opens({},'html/index.html')